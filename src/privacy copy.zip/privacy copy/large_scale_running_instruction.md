
1. run large_scale_data_preparation.py to prepare data
2. run large_scale_train_privacy_federated_all.sh; large_scale_test_privacy_federated_all.sh on the 1st server
3. run large_scale_train_privacy_federated_decoder.sh; large_scale_test_privacy_federated_decoder.sh on the 2nd server
4. run large_scale_train_privacy_joint.sh; large_scale_test_privacy_joint.sh on the 3rd server
5. run large_scale_train_server_4.sh; large_scale_test_server_4.sh on the 4th server
