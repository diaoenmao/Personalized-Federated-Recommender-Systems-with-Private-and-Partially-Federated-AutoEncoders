  store_local_optimizer: 0
  use_global_optimizer_lr: 0
  partial_average_shuffle: 1
  partial_average_ratio: 0.1

   # if 'partial_average_shuffle' in cfg['control']:
    #     cfg['partial_average_shuffle'] = True if int(cfg['control']['partial_average_shuffle']) == 1 else False
    # if 'partial_average_ratio' in cfg['control']:
    #     cfg['partial_average_ratio'] = float(cfg['control']['partial_average_ratio'])
    # if 'weighted_average_method' in cfg['control']:
    #     cfg['weighted_average_method'] = cfg['control']['weighted_average_method']
    # if 'partial_epoch' in cfg['control']:
    #     cfg['partial_epoch'] = int(cfg['control']['partial_epoch'])
    # cfg['store_local_optimizer'] = True if int(cfg['control']['store_local_optimizer']) == 1 else False
    # cfg['use_global_optimizer_lr'] = True if int(cfg['control']['use_global_optimizer_lr']) == 1 else False